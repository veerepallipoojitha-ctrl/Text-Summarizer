const stopWords = new Set([

    "the", "is", "a", "an", "and",
    "or", "but", "of", "to", "in",
    "on", "for", "with", "as", "by",
    "at", "from", "this", "that",
    "these", "those", "it", "its",
    "are", "was", "were", "be",
    "been", "being", "has", "have",
    "had", "will", "would", "can",
    "could", "should", "may",
    "might", "do", "does", "did",
    "i", "you", "he", "she",
    "we", "they", "my", "your",
    "our", "their", "me", "him",
    "her", "them"

]);


function summarizeText() {

    const text = document
        .getElementById("textInput")
        .value
        .trim();

    const summaryBox =
        document.getElementById("summary");


    if (text === "") {

        summaryBox.innerText =
            "Please enter some text.";

        return;
    }


    const sentences = text
        .match(/[^.!?]+[.!?]+|[^.!?]+$/g)
        ?.map(sentence => sentence.trim())
        .filter(sentence => sentence.length > 0)
        || [];


    if (sentences.length <= 2) {

        summaryBox.innerText = text;

        return;
    }


    // ===================================
    // WORD FREQUENCY
    // ===================================

    const frequency = {};


    sentences.forEach(sentence => {

        const words =
            sentence
                .toLowerCase()
                .match(/[a-zA-Z]+/g) || [];


        words.forEach(word => {

            if (
                word.length > 2 &&
                !stopWords.has(word)
            ) {

                frequency[word] =
                    (frequency[word] || 0) + 1;

            }

        });

    });


    // ===================================
    // SCORE SENTENCES
    // ===================================

    const scoredSentences =
        sentences.map((sentence, index) => {

            const words =
                sentence
                    .toLowerCase()
                    .match(/[a-zA-Z]+/g) || [];


            let score = 0;


            words.forEach(word => {

                if (frequency[word]) {

                    score += frequency[word];

                }

            });


            return {
                index: index,
                sentence: sentence,
                score: score
            };

        });


    // ===================================
    // SELECT TOP SENTENCES
    // ===================================

    const numberToSelect =
        Math.max(
            1,
            Math.ceil(sentences.length * 0.3)
        );


    const selected =
        scoredSentences
            .sort((a, b) => b.score - a.score)
            .slice(0, numberToSelect);


    // Restore original order

    selected.sort(
        (a, b) => a.index - b.index
    );


    const summary =
        selected
            .map(item => item.sentence)
            .join(" ");


    summaryBox.innerText = summary;
}


function clearText() {

    document.getElementById("textInput").value = "";

    document.getElementById("summary").innerText =
        "Your summary will appear here.";

}